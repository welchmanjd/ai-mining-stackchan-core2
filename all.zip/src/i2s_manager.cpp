#include "i2s_manager.h"
#include "logging.h"

static const char* kEvtTag = "I2S_OWNER"; // EVT tag requested

I2SManager& I2SManager::instance() {
  static I2SManager g;
  return g;
}

I2SManager::I2SManager() {
  mutex_ = xSemaphoreCreateRecursiveMutex();
  if (!mutex_) {
    mc_logf("[I2S] ERROR: xSemaphoreCreateRecursiveMutex failed");
  } else {
    mc_logf("[I2S] mutex created");
  }
}

const char* I2SManager::ownerToStr_(Owner o) const {
  switch (o) {
    case Owner::None:    return "None";
    case Owner::Mic:     return "Mic";
    case Owner::Speaker: return "Speaker";
    default:             return "?";
  }
}

bool I2SManager::lockForMic(const char* callsite, uint32_t timeoutMs) {
  return lock_(Owner::Mic, callsite, timeoutMs);
}

bool I2SManager::lockForSpeaker(const char* callsite, uint32_t timeoutMs) {
  return lock_(Owner::Speaker, callsite, timeoutMs);
}

bool I2SManager::lock_(Owner want, const char* callsite, uint32_t timeoutMs) {
  if (!mutex_) return false;

  const uint32_t t0 = millis();
  const TickType_t ticks = (timeoutMs == 0) ? 0 : pdMS_TO_TICKS(timeoutMs);

  // Snapshot for fail log (non-atomic is fine for diagnostics)
  const Owner snapOwner = owner_;
  const char* snapSite = owner_callsite_;
  const uint32_t snapSince = owner_since_ms_;

  const BaseType_t ok = xSemaphoreTakeRecursive(mutex_, ticks);
  const uint32_t waited = millis() - t0;

  if (ok != pdTRUE) {
    const uint32_t heldMs = (snapOwner == Owner::None) ? 0 : (millis() - snapSince);
    mc_logf("[I2S] lock FAIL want=%s waited=%lums cur=%s held=%lums curSite=%s reqSite=%s",
            ownerToStr_(want),
            (unsigned long)waited,
            ownerToStr_(snapOwner),
            (unsigned long)heldMs,
            snapSite ? snapSite : "",
            callsite ? callsite : "");
    LOG_EVT_INFO(kEvtTag, "lock_fail want=%s waited=%lums cur=%s held=%lums",
                 ownerToStr_(want),
                 (unsigned long)waited,
                 ownerToStr_(snapOwner),
                 (unsigned long)heldMs);
    return false;
  }

  // Acquired
  TaskHandle_t me = xTaskGetCurrentTaskHandle();

  // First entry => owner transition
  if (lock_depth_ == 0) {
    const Owner prev = owner_;
    const char* prevSite = owner_callsite_;
    const uint32_t prevHeldMs = (prev == Owner::None) ? 0 : (millis() - owner_since_ms_);

    owner_ = want;
    owner_task_ = me;
    owner_callsite_ = callsite ? callsite : "";
    owner_since_ms_ = millis();

    mc_logf("[I2S] owner %s -> %s waited=%lums prevHeld=%lums site=%s",
            ownerToStr_(prev),
            ownerToStr_(want),
            (unsigned long)waited,
            (unsigned long)prevHeldMs,
            owner_callsite_);

    LOG_EVT_INFO(kEvtTag, "owner %s->%s waited=%lums prevHeld=%lums site=%s",
                 ownerToStr_(prev),
                 ownerToStr_(want),
                 (unsigned long)waited,
                 (unsigned long)prevHeldMs,
                 owner_callsite_);

    if (prev != Owner::None && prevSite && prevSite[0]) {
      mc_logf("[I2S]   prevSite=%s", prevSite);
    }
  } else {
    // Recursive re-lock (same task expected)
    mc_logf("[I2S] lock reenter owner=%s depth=%lu waited=%lums site=%s",
            ownerToStr_(owner_),
            (unsigned long)lock_depth_,
            (unsigned long)waited,
            callsite ? callsite : "");
  }

  lock_depth_++;
  return true;
}

void I2SManager::unlock(const char* callsite) {
  if (!mutex_) return;

  if (lock_depth_ == 0) {
    mc_logf("[I2S] unlock WARN depth=0 callsite=%s", callsite ? callsite : "");
    return;
  }

  // Depth bookkeeping first (so logs reflect new depth)
  lock_depth_--;

  // Last unlock => owner becomes None
  if (lock_depth_ == 0) {
    const Owner prev = owner_;
    const uint32_t heldMs = (prev == Owner::None) ? 0 : (millis() - owner_since_ms_);
    const char* prevSite = owner_callsite_;

    owner_ = Owner::None;
    owner_task_ = nullptr;
    owner_callsite_ = "";
    owner_since_ms_ = 0;

    mc_logf("[I2S] owner %s -> None held=%lums unlockSite=%s",
            ownerToStr_(prev),
            (unsigned long)heldMs,
            callsite ? callsite : "");
    LOG_EVT_INFO(kEvtTag, "owner %s->None held=%lums unlockSite=%s",
                 ownerToStr_(prev),
                 (unsigned long)heldMs,
                 callsite ? callsite : "");

    if (prevSite && prevSite[0]) {
      mc_logf("[I2S]   prevSite=%s", prevSite);
    }
  }

  xSemaphoreGiveRecursive(mutex_);
}
