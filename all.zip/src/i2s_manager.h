#pragma once
#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

// I2SManager
// - Mic/Speaker の I2S 初期化(begin/end) を「排他 + owner 可視化」するための薄いクラス
// - 使い方: lockForMic()/lockForSpeaker() してから begin/end/play 等を行い、最後に unlock()
class I2SManager {
public:
  enum class Owner : uint8_t { None = 0, Mic = 1, Speaker = 2 };

  static I2SManager& instance();

  // timeoutMs: xSemaphoreTakeRecursive の待ち時間（0=ノンブロッキング）
  bool lockForMic(const char* callsite, uint32_t timeoutMs = 2000);
  bool lockForSpeaker(const char* callsite, uint32_t timeoutMs = 2000);

  void unlock(const char* callsite);

  Owner owner() const { return owner_; }
  const char* ownerCallsite() const { return owner_callsite_; }
  uint32_t ownerSinceMs() const { return owner_since_ms_; }
  uint32_t lockDepth() const { return lock_depth_; }

private:
  I2SManager();
  bool lock_(Owner want, const char* callsite, uint32_t timeoutMs);
  const char* ownerToStr_(Owner o) const;

private:
  SemaphoreHandle_t mutex_ = nullptr;     // recursive mutex
  TaskHandle_t owner_task_ = nullptr;    // task holding the mutex (diagnostics)
  volatile Owner owner_ = Owner::None;
  const char* owner_callsite_ = "";
  uint32_t owner_since_ms_ = 0;
  uint32_t lock_depth_ = 0;
};
